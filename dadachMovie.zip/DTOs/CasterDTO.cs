namespace dadachAPI.DTOs
{
    public class CasterDTO
    {
        public int PersonId { get; set; }
        public string Character { get; set; }
        public string PersonName { get; set; }
    }
}