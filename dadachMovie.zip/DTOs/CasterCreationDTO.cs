namespace dadachAPI.DTOs
{
    public class CasterCreationDTO
    {
        public int PersonId { get; set; }
        public string Character { get; set; }
    }
}