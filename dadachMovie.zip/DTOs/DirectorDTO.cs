namespace dadachAPI.DTOs
{
    public class DirectorDTO
    {
        
    }
}