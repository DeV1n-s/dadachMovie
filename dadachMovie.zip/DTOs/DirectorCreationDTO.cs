namespace dadachAPI.DTOs
{
    public class DirectorCreationDTO
    {
        
    }
}